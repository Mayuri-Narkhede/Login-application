package com.example.Repositery;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.entity.RegisterUser;

public interface IregisterUserRepositery extends JpaRepository<RegisterUser, Long> {
	@Query(value="select * from RegisterUser where file_id=(select file_id from File)",nativeQuery=true)
	List<RegisterUser> getBasicInfo(String file_id);
}
