package com.example.Repositery;

import org.springframework.data.jpa.repository.Query;

import com.example.entity.File;

public class IfileRespositery {
	
}
