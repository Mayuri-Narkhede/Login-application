package com.example.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.Repositery.IfileRespositery;
import com.example.entity.File;

@Service
@Transactional
public class fileService implements Ifile {
	@Autowired
	private IfileRespositery ifileRepositery;
	
	@Override
	public File addFile(File file)
	{
		// TODO Auto-generated method stub
		return ifileRepositery.save(file);
	}

	@Override
	public boolean deleteFile(long id)
	{
		ifileRepositery.deleteById(id);
		return true;
	}
	
	public List<File> allAvailableFiles()
	{
		return ifileRepositery.findAll();
	}
}
