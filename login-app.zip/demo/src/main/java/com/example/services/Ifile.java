package com.example.services;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.example.entity.File;

public interface Ifile {
	File addFile(File file);
	boolean deleteFile(long id);
	List<File> allAvailableFiles();
}
