package com.example.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.Repositery.IregisterUserRepositery;
import com.example.entity.RegisterUser;

public abstract class IregisterUserService implements IregisterUser {
	@Autowired
	private IregisterUserRepositery IregisterUserRepositery;
	
	@Override
	public RegisterUser addRegisterUser(RegisterUser RegisterUser) {
		return IregisterUserRepositery.save(RegisterUser);
	}
	
	@Override
	public List<RegisterUser> allAvailableUser()
	{
		return IregisterUserRepositery.findAll();
	}
//	@Override
//	public List<RegisterUser> getDetailInfo(String file_id){
//		System.out.println(file_id);
//		return IregisterUserRepositery.getBasicInfo(file_id);
//	}
	
}
