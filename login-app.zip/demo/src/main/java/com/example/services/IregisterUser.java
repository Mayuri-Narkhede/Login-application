package com.example.services;

import java.util.List;

import com.example.entity.RegisterUser;

public interface IregisterUser {
	RegisterUser addRegisterUser(RegisterUser RegisterUser);
	List<RegisterUser> allAvailableUser();
	List<RegisterUser> getBasicInfo(String file_id);
}
