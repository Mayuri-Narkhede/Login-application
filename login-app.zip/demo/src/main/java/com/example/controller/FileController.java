package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.File;
import com.example.services.Ifile;

@RestController
@RequestMapping("/file")
@CrossOrigin(origins = "http://localhost:3000")
public class FileController {
	
	@Autowired
	private Ifile ifile;
	
	@PostMapping("/add")
	public File addFile(@RequestBody File file) 
	{
		return ifile.addFile(file);
	}
	
	@DeleteMapping("/delete/{id}")
	public boolean deleteFile(long id)
	{
		return ifile.deleteFile(id);
	}
	
	@GetMapping("/list")
	public List<File> allFiles()
	{
		return ifile.allAvailableFiles();
	}

}
