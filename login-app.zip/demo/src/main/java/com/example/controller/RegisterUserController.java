package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entity.RegisterUser;
import com.example.services.IregisterUser;

@RestController
@RequestMapping("/master")
@CrossOrigin(origins = "http://localhost:3000")
public class RegisterUserController {
	
	@Autowired
	private IregisterUser iregisterUser;
	
	@PostMapping("/add")
	public RegisterUser addRegisterUser(@RequestBody RegisterUser registerUser)
	{
		return iregisterUser.addRegisterUser(registerUser);
	}
	
	@PostMapping("/list")
	public List<RegisterUser> allUser()
	{
		return iregisterUser.allAvailableUser();
	}
	
	

}
